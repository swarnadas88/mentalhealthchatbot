import schedule, time

def send_daily_checkin():
    print("Daily Check-in: How are you feeling today? 😊")

schedule.every().day.at("10:00").do(send_daily_checkin)

while True:
    schedule.run_pending()
    time.sleep(1)
