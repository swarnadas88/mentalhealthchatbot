import streamlit as st
import matplotlib.pyplot as plt

st.title("User Sentiment Over Time")

sentiments = [1, 2, 3, 2, 1]  # Example values

plt.plot(sentiments, marker="o", color="purple")
plt.xlabel("Days")
plt.ylabel("Sentiment Score")
st.pyplot(plt)
